# RajCut website (beta)

## What is included
- Responsive browser-based video editor UI for Android and Windows browsers.
- Local video preview.
- Start/end trimming controls, including "set start/end here".
- MP4 export powered by FFmpeg.wasm in the browser.
- No login, server-side video upload, or paid API required for this first version.

## Run locally
Because the editor loads JavaScript modules, serve the folder over HTTP rather than opening the HTML file directly.

Python:
    python -m http.server 8000

Then open:
    http://localhost:8000

## Publish free
A simple option is GitHub Pages:
1. Create a GitHub account (a parent/guardian can help if needed).
2. Create a public repository named `rajcut`.
3. Upload `index.html` and this README.
4. In repository Settings -> Pages, choose deploy from branch `main`, folder `/root`.
5. Wait for GitHub Pages to publish the site. The public URL will be shown in Pages settings.

You can also deploy the folder using a free static-site hosting tier.

## Important limitations
- This is an early beta, not a complete professional editor.
- It currently supports one video at a time and trimming/export only.
- FFmpeg.wasm downloads its processing engine from public CDNs on first export, so internet is required for that step.
- Export is performed on the user's device. Large/4K files can be slow or may exceed browser memory.
- Browser codec support varies. MP4/H.264 is the intended export format.
- Do not close the tab during export.
- A real public launch should add a privacy page, accessibility checks, device testing, and clear browser compatibility messaging.
